﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt



.. _installation:

Installation
------------


.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   Installing/Index
   SetupCheck/Index
   SchedulerUser/Index
   SchedulerShellScript/Index
   CronJob/Index
   BaseTasks/Index

