﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: Includes.txt

.. _index-labels-for-crossreferencing:

Index: Labels for Crossreferencing
==================================

.. ref-targets-list::
